package com.gt.electronichomes.domain.service;

import com.gt.electronichomes.domain.dto.RolEmpleadoDTO;
import com.gt.electronichomes.domain.repository.RolEmpleadoDTORepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RolEmpleadoService {
    @Autowired
    private RolEmpleadoDTORepository redtor;

    public List<RolEmpleadoDTO> lista() {
        return redtor.lista();
    }

}
