package com.gt.electronichomes.persistence.mapper;

import com.gt.electronichomes.domain.dto.EmpleadoDTO;
import com.gt.electronichomes.persistence.entity.Empleado;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring", uses = {RolEmpleadoDTOMapper.class, EstablecimientoDTOMapper.class})
public interface EmpleadoDTOMapper {

    EmpleadoDTO toEmpleadoDTO(Empleado empleado);
    List<EmpleadoDTO> toEmpleadosDTO(List<Empleado> empleados);

    @InheritInverseConfiguration
    @Mapping(target="ventas", ignore = true)
    Empleado toEmpleado(EmpleadoDTO empleadoDTO);
}

