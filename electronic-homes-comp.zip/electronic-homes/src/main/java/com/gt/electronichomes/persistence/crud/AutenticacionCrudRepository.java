package com.gt.electronichomes.persistence.crud;

import com.gt.electronichomes.persistence.entity.Empleado;
import org.springframework.data.repository.CrudRepository;

public interface AutenticacionCrudRepository extends CrudRepository<Empleado, Integer> {

    Empleado findByUsuarioAndContrasena(String nombre, String contrasena);



}
