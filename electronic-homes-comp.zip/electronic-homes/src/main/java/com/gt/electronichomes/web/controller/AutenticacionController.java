package com.gt.electronichomes.web.controller;

import com.gt.electronichomes.domain.dto.EmpleadoDTO;
import com.gt.electronichomes.domain.dto.PermisoDTO;
import com.gt.electronichomes.domain.service.AutenticacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins="http://localhost:4200",maxAge=3600)
@RestController
@RequestMapping("/login")
public class AutenticacionController {
    @Autowired
    private AutenticacionService as;

    @PostMapping("/log")
    public PermisoDTO autenticar(@RequestBody EmpleadoDTO empleadoDTO) {
        return as.autenticar(empleadoDTO);
    }
}
