package com.gt.electronichomes.domain.repository;

import com.gt.electronichomes.domain.dto.ProductoDTO;

import java.util.List;

public interface ProductoDTORepository {
    public List<ProductoDTO> listar(Integer idEstablecimiento);

    public ProductoDTO transferir(ProductoDTO productoDTO);

    public ProductoDTO agregar(ProductoDTO productoDTO);

    public ProductoDTO editar(ProductoDTO productoDTO);
}
