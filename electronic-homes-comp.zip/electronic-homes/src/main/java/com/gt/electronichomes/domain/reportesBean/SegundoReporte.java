package com.gt.electronichomes.domain.reportesBean;

import java.math.BigDecimal;

public class SegundoReporte {
    private BigDecimal total;
    private String nombreCliente;
    private String nit;

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }
}
