package com.gt.electronichomes.persistence.repository;

import com.gt.electronichomes.domain.reportesBean.*;
import com.gt.electronichomes.domain.repository.ReportesDTORepository;
import com.gt.electronichomes.persistence.crud.ReportesQuerysRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

@Repository
public class ReportesRepository implements ReportesDTORepository {

    @Autowired
    private ReportesQuerysRepository rqr;

    @Override
    public List<PrimerReporte> masVendidoR1() {
        List<Object[]> obj = rqr.masVendidoR1();
        List<PrimerReporte> registrosPR = new ArrayList<>();
        for (Object[] o: obj) {
            PrimerReporte tmp = new PrimerReporte();
            tmp.setVentas((BigInteger) o[0]);
            tmp.setNombre((String) o[1]);
            registrosPR.add(tmp);
        }
        return registrosPR;
    }

    @Override
    public List<SegundoReporte> clientesTopR2() {
        List<Object[]> obj = rqr.clientesTopR2();
        List<SegundoReporte> registrosPR = new ArrayList<>();
        for (Object[] o: obj) {
            SegundoReporte tmp = new SegundoReporte();
            tmp.setTotal((BigDecimal) o[0]);
            tmp.setNombreCliente((String) o[1]);
            tmp.setNit((String) o[2]);
            registrosPR.add(tmp);
        }
        return registrosPR;
    }

    @Override
    public List<TercerReporte> sucursalesTopVentasR3() {
        List<Object[]> obj = rqr.sucursalesTopVentasR3();
        List<TercerReporte> registrosPR = new ArrayList<>();
        for (Object[] o: obj) {
            TercerReporte tmp = new TercerReporte();
            tmp.setNoVentas((BigInteger) o[0]);
            tmp.setNombreEstablecimiento((String) o[1]);
            registrosPR.add(tmp);
        }
        return registrosPR;
    }

    @Override
    public List<CuartoReporte> sucursalesTopIngresosR4() {
        List<Object[]> obj = rqr.sucursalesTopIngresosR4();
        List<CuartoReporte> registrosPR = new ArrayList<>();
        for (Object[] o: obj) {
            CuartoReporte tmp = new CuartoReporte();
            tmp.setTotal((BigDecimal) o[0]);
            tmp.setNombreEstablecimiento((String) o[1]);
            registrosPR.add(tmp);
        }
        return registrosPR;
    }

    @Override
    public List<QuintoReporte> empleadosTopVentasR5() {
        List<Object[]> obj = rqr.empleadosTopVentasR5();
        List<QuintoReporte> registrosPR = new ArrayList<>();
        for (Object[] o: obj) {
            QuintoReporte tmp = new QuintoReporte();
            tmp.setIdEmpleado((Integer) o[0]);
            tmp.setNombreEmpleado((String) o[1]);
            tmp.setNoVentas((BigInteger) o[2]);
            registrosPR.add(tmp);
        }
        return registrosPR;
    }

    @Override
    public List<SextoReporte> empleadosTopIngresosR6() {
        List<Object[]> obj = rqr.empleadosTopIngresosR6();
        List<SextoReporte> registrosPR = new ArrayList<>();
        for (Object[] o: obj) {
            SextoReporte tmp = new SextoReporte();
            tmp.setIdEmpleado((Integer) o[0]);
            tmp.setNombreEmpleado((String) o[1]);
            tmp.setTotal((BigDecimal) o[2]);
            registrosPR.add(tmp);
        }
        return registrosPR;
    }

    @Override
    public List<SeptimoReporte> productosTopVentasR7() {
        List<Object[]> obj = rqr.productosTopVentasR7();
        List<SeptimoReporte> registrosPR = new ArrayList<>();
        for (Object[] o: obj) {
            SeptimoReporte tmp = new SeptimoReporte();
            tmp.setNoVentas((BigInteger) o[0]);
            tmp.setNombreProducto((String) o[1]);
            registrosPR.add(tmp);
        }
        return registrosPR;
    }

    @Override
    public List<OctavoReporte> productosTopIngresosR8() {
        List<Object[]> obj = rqr.productosTopIngresosR8();
        List<OctavoReporte> registrosPR = new ArrayList<>();
        for (Object[] o: obj) {
            OctavoReporte tmp = new OctavoReporte();
            tmp.setTotal((BigDecimal) o[0]);
            tmp.setNombreProducto((String) o[1]);
            registrosPR.add(tmp);
        }
        return registrosPR;
    }

    @Override
    public List<NovenoReporte> productosTopVentasSucursalR9(Integer idEstablecimiento) {
        List<Object[]> obj = rqr.productosTopVentasSucursalR9(idEstablecimiento);
        List<NovenoReporte> registrosPR = new ArrayList<>();
        for (Object[] o: obj) {
            NovenoReporte tmp = new NovenoReporte();
            tmp.setNoVentas((BigInteger) o[0]);
            tmp.setNombreProducto((String) o[1]);
            registrosPR.add(tmp);
        }
        return registrosPR;
    }

    @Override
    public List<DecimoReporte> productosTopIngresosSucursalR10(Integer idEstablecimiento) {
        List<Object[]> obj = rqr.productosTopIngresosSucursalR10(idEstablecimiento);
        List<DecimoReporte> registrosPR = new ArrayList<>();
        for (Object[] o: obj) {
            DecimoReporte tmp = new DecimoReporte();
            tmp.setNoVentas((BigDecimal) o[0]);
            tmp.setNombreProducto((String) o[1]);
            registrosPR.add(tmp);
        }
        return registrosPR;
    }
}
