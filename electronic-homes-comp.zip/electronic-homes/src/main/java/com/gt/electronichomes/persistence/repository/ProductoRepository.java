package com.gt.electronichomes.persistence.repository;

import com.gt.electronichomes.domain.dto.ProductoDTO;
import com.gt.electronichomes.domain.repository.ProductoDTORepository;
import com.gt.electronichomes.persistence.crud.ProductoCrudRepository;
import com.gt.electronichomes.persistence.entity.Producto;
import com.gt.electronichomes.persistence.mapper.ProductoDTOMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ProductoRepository implements ProductoDTORepository {
    @Autowired
    private ProductoCrudRepository pcr;

    @Autowired
    private ProductoDTOMapper pdtom;

    @Override
    public List<ProductoDTO> listar(Integer idEstablecimiento) {
        List<Producto> productos = pcr.findProductoByIdEstablecimientoAndDisponible(idEstablecimiento, true);
        return pdtom.toProductosDTO(productos);
    }

    @Override
    public ProductoDTO transferir(ProductoDTO productoDTO) {
        Producto producto = pcr.save(pdtom.toProducto(productoDTO));
        return pdtom.toProductoDTO(producto);
    }

    @Override
    public ProductoDTO agregar(ProductoDTO productoDTO) {
        Producto producto = pcr.save(pdtom.toProducto(productoDTO));
        return pdtom.toProductoDTO(producto);
    }

    @Override
    public ProductoDTO editar(ProductoDTO productoDTO) {
        Producto producto = pcr.save(pdtom.toProducto(productoDTO));
        return pdtom.toProductoDTO(producto);
    }
}
