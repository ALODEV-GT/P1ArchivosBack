package com.gt.electronichomes.domain.dto;

public class PermisoDTO {
    private RolEmpleadoDTO rol;
    private EstablecimientoDTO establecimiento;
    private Integer idEmpleado;
    private String nombreEmpleado;

    public PermisoDTO(RolEmpleadoDTO rol, EstablecimientoDTO establecimiento, Integer idEmpleado, String nombreEmpleado){
        this.rol = rol;
        this.establecimiento = establecimiento;
        this.idEmpleado = idEmpleado;
        this.nombreEmpleado = nombreEmpleado;
    }

    public PermisoDTO(){

    }

    public Integer getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(Integer idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public RolEmpleadoDTO getRol() {
        return rol;
    }

    public void setRol(RolEmpleadoDTO rol) {
        this.rol = rol;
    }

    public EstablecimientoDTO getEstablecimiento() {
        return establecimiento;
    }

    public void setEstablecimiento(EstablecimientoDTO establecimiento) {
        this.establecimiento = establecimiento;
    }
}
