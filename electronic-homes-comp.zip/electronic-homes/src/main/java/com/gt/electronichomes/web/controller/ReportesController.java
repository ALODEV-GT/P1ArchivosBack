package com.gt.electronichomes.web.controller;

import com.gt.electronichomes.domain.dto.ClienteDTO;
import com.gt.electronichomes.domain.reportesBean.*;
import com.gt.electronichomes.domain.service.ReportesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200",maxAge=3600)
@RestController
@RequestMapping("/reportes")
public class ReportesController {
    @Autowired
    private ReportesService rs;

    @GetMapping("/mas-vendido")
    public List<PrimerReporte> masVendido() {
        return rs.masVendidoR1();
    }

    @GetMapping("/clientes-top")
    public List<SegundoReporte> clientesTop() {
        return rs.clientesTopR2();
    }

    @GetMapping("/sucursales-top-ventas")
    public List<TercerReporte> sucursalesTopVentas() {
        return rs.sucursalesTopVentasR3();
    }

    @GetMapping("/sucursales-top-ingresos")
    public List<CuartoReporte> sucursalesTopIngresos() {
        return rs.sucursalesTopIngresosR4();
    }

    @GetMapping("/empleado-top-ventas")
    public List<QuintoReporte> empleadosTopVentas() {
        return rs.empleadosTopVentasR5();
    }

    @GetMapping("/empleado-top-ingresos")
    public List<SextoReporte> empleadosTopIngresos() {
        return rs.empleadosTopIngresosR6();
    }

    @GetMapping("/productos-top-ventas")
    public List<SeptimoReporte> productosTopVentas() {
        return rs.productosTopVentasR7();
    }

    @GetMapping("/productos-top-ingresos")
    public List<OctavoReporte> productosTopIngresos() {
        return rs.productosTopIngresosR8();
    }

    @GetMapping("/productos-top-ventas-sucursal/{idEstablecimiento}")
    public List<NovenoReporte> productosTopVentasSucursal(@PathVariable Integer idEstablecimiento) {
        return rs.productosTopVentasSucursalR9(idEstablecimiento);
    }

    @GetMapping("/productos-top-ingresos-sucursal/{idEstablecimiento}")
    public List<DecimoReporte> productosTopIngresosSucursal(@PathVariable Integer idEstablecimiento) {
        return rs.productosTopIngresosSucursalR10(idEstablecimiento);
    }



}
