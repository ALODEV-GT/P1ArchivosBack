package com.gt.electronichomes.persistence.repository;

import com.gt.electronichomes.domain.dto.EmpleadoDTO;
import com.gt.electronichomes.domain.dto.EstablecimientoDTO;
import com.gt.electronichomes.domain.dto.PermisoDTO;
import com.gt.electronichomes.domain.dto.RolEmpleadoDTO;
import com.gt.electronichomes.domain.repository.EmpleadoDTORepository;
import com.gt.electronichomes.persistence.crud.EmpleadoCrudRepository;
import com.gt.electronichomes.persistence.crud.VentaCrudRepository;
import com.gt.electronichomes.persistence.entity.Cliente;
import com.gt.electronichomes.persistence.entity.Empleado;
import com.gt.electronichomes.persistence.entity.Venta;
import com.gt.electronichomes.persistence.mapper.EmpleadoDTOMapper;
import com.gt.electronichomes.persistence.mapper.EstablecimientoDTOMapper;
import com.gt.electronichomes.persistence.mapper.RolEmpleadoDTOMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EmpleadoRepository implements EmpleadoDTORepository {
    @Autowired
    private EmpleadoCrudRepository ecr;

    @Autowired
    private EmpleadoDTOMapper edtom;

    @Autowired
    private RolEmpleadoDTOMapper redtom;

    @Autowired
    private EstablecimientoDTOMapper estdtom;

    @Autowired
    private VentaCrudRepository vcr;

    @Override
    public EmpleadoDTO agregar(EmpleadoDTO empleadoDTO) {
        Empleado empleado = ecr.save(edtom.toEmpleado(empleadoDTO));
        return edtom.toEmpleadoDTO(empleado);
    }

    @Override
    public List<EmpleadoDTO> lista() {
        List<Empleado> empleados = (List<Empleado>) ecr.findAll();
        return edtom.toEmpleadosDTO(empleados);
    }

    @Override
    public Boolean eliminar(EmpleadoDTO empleadoDTO) {
        Empleado vendedorComodin = ecr.findByUsuario("comodin");
        List<Venta> ventas = vcr.findAllByIdEmpleado(empleadoDTO.getIdEmpleado());

        for (Venta venta: ventas) {
            venta.setIdEmpleado(vendedorComodin.getIdEmpleado());
            venta.setEmpleado(vendedorComodin);
        }

        vcr.saveAll(ventas);

        ecr.delete(edtom.toEmpleado(empleadoDTO));
        if(ecr.findByUsuario(empleadoDTO.getUsuario()) == null){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public EmpleadoDTO editar(EmpleadoDTO empleadoDTO) {
        Empleado empleado = ecr.save(edtom.toEmpleado(empleadoDTO));
        return edtom.toEmpleadoDTO(empleado);
    }

    @Override
    public PermisoDTO validar(EmpleadoDTO empleadoDTO) {
        Empleado empleado = edtom.toEmpleado(empleadoDTO);
        Empleado emp = ecr.findByUsuario(empleado.getUsuario());
        if (emp == null){
            RolEmpleadoDTO rol = new RolEmpleadoDTO(0,"inexistente");
            EstablecimientoDTO establecimiento = new EstablecimientoDTO();
            return new PermisoDTO(rol, establecimiento, 0,"");
        }else{
            RolEmpleadoDTO rol =  redtom.toRolEmpleadoDTO(emp.getRolEmpleado());
            EstablecimientoDTO establecimiento = estdtom.toEstablecimientoDTO(emp.getEstablecimiento());
            return new PermisoDTO(rol, establecimiento, emp.getIdEmpleado(), emp.getNombre());
        }
    }
}
