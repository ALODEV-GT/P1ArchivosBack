package com.gt.electronichomes.domain.reportesBean;

import java.math.BigInteger;

public class NovenoReporte {
    private BigInteger noVentas;
    private String nombreProducto;

    public BigInteger getNoVentas() {
        return noVentas;
    }

    public void setNoVentas(BigInteger noVentas) {
        this.noVentas = noVentas;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }
}
