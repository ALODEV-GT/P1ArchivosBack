package com.gt.electronichomes.web.controller;

import com.gt.electronichomes.domain.dto.EmpleadoDTO;
import com.gt.electronichomes.domain.dto.RolEmpleadoDTO;
import com.gt.electronichomes.domain.service.RolEmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200",maxAge=3600)
@RestController
@RequestMapping("/rol-empleado")
public class RolEmpleadoController {

    @Autowired
    private RolEmpleadoService res;

    @GetMapping("/lista")
    public List<RolEmpleadoDTO> lista() {
        return res.lista();
    }

}
