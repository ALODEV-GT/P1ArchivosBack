package com.gt.electronichomes.persistence.repository;

import com.gt.electronichomes.domain.repository.TipoProductoDTORepository;
import org.springframework.stereotype.Repository;

@Repository
public class TipoProductoRepository implements TipoProductoDTORepository {
}
