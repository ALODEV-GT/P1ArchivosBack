package com.gt.electronichomes.domain.service;

import com.gt.electronichomes.domain.dto.VentaDTO;
import com.gt.electronichomes.domain.dto.VentaGDTO;
import com.gt.electronichomes.domain.repository.VentaDTORepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VentaService {
    @Autowired
    private VentaDTORepository vdtor;

    public VentaDTO comprar(VentaGDTO venta){
        return vdtor.comprar(venta);
    }

}
