package com.gt.electronichomes.persistence.crud;

import com.gt.electronichomes.persistence.entity.Venta;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface VentaCrudRepository extends CrudRepository<Venta,Integer> {
    public List<Venta> findAllByNitCliente(String nitCliente);

    public List<Venta> findAllByIdEmpleado(Integer idEmpleado);
}
