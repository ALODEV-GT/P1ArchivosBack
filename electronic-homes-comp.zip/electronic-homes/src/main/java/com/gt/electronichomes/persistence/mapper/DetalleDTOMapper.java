package com.gt.electronichomes.persistence.mapper;

import com.gt.electronichomes.domain.dto.DetalleDTO;
import com.gt.electronichomes.persistence.entity.Detalle;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", uses = {VentaDTOMapper.class, ProductoDTOMapper.class})
public interface DetalleDTOMapper {

    DetalleDTO toDetalleDTO(Detalle detalle);

    @InheritInverseConfiguration
    @Mapping(target = "id", ignore = true)
    Detalle toDetalle(DetalleDTO detalle);

}
