package com.gt.electronichomes.persistence.entity;

import javax.persistence.*;

@Entity
@Table(name = "detalle")
public class Detalle {

    @EmbeddedId
    private DetallePK id;

    @ManyToOne
    @JoinColumn(name = "id_venta", insertable = false, updatable = false)
    private Venta venta;

    @OneToOne
    @JoinColumn(name = "id_producto", insertable = false, updatable = false)
    private Producto producto;

    public Detalle(){}

    public Detalle(DetallePK id){
        this.id = id;
    }

    public DetallePK getId() {
        return id;
    }

    public void setId(DetallePK id) {
        this.id = id;
    }

    public Venta getVenta() {
        return venta;
    }

    public void setVenta(Venta venta) {
        this.venta = venta;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }
}
