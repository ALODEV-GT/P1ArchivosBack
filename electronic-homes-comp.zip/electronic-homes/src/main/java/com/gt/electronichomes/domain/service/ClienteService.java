package com.gt.electronichomes.domain.service;

import com.gt.electronichomes.domain.dto.ClienteDTO;
import com.gt.electronichomes.domain.repository.ClienteDTORepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClienteService {
    @Autowired
    private ClienteDTORepository cdtor;

    public ClienteDTO validar(ClienteDTO cliente){
        return cdtor.validar(cliente);
    }

    public ClienteDTO agregar(ClienteDTO cliente){
        return cdtor.agregar(cliente);
    }

    public List<ClienteDTO> lista(){
        return cdtor.lista();
    }

    public Boolean eliminar(String nit){
       return cdtor.eliminar(nit);
    }

    public ClienteDTO editar(ClienteDTO clienteDTO) {
        return cdtor.editar(clienteDTO);
    }

}
