package com.gt.electronichomes.domain.reportesBean;

import java.math.BigDecimal;

public class CuartoReporte {
    private BigDecimal total;
    private String nombreEstablecimiento;

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public String getNombreEstablecimiento() {
        return nombreEstablecimiento;
    }

    public void setNombreEstablecimiento(String nombreEstablecimiento) {
        this.nombreEstablecimiento = nombreEstablecimiento;
    }
}
