package com.gt.electronichomes.domain.reportesBean;

import java.math.BigInteger;

public class TercerReporte {
    private BigInteger noVentas;
    private String nombreEstablecimiento;

    public BigInteger getNoVentas() {
        return noVentas;
    }

    public void setNoVentas(BigInteger noVentas) {
        this.noVentas = noVentas;
    }

    public String getNombreEstablecimiento() {
        return nombreEstablecimiento;
    }

    public void setNombreEstablecimiento(String nombreEstablecimiento) {
        this.nombreEstablecimiento = nombreEstablecimiento;
    }
}
