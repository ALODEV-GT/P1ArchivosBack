package com.gt.electronichomes.persistence.entity;

import javax.persistence.*;

@Entity
@Table(name = "producto")
public class Producto {
     @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     @Column(name = "id_producto")
     private Integer idProducto;

     @Column(name = "id_establecimiento")
     private Integer idEstablecimiento;

     private String nombre;

     private Double precio;

     private Boolean disponible;

     @ManyToOne
     @JoinColumn(name = "id_establecimiento", insertable = false, updatable = false)
     private Establecimiento establecimiento;

     @OneToOne(mappedBy = "producto")
     private Detalle detalle;

     public Boolean getDisponible() {
          return disponible;
     }

     public void setDisponible(Boolean disponible) {
          this.disponible = disponible;
     }

     public String getNombre() {
          return nombre;
     }

     public void setNombre(String nombre) {
          this.nombre = nombre;
     }

     public Integer getIdProducto() {
          return idProducto;
     }

     public void setIdProducto(Integer idProducto) {
          this.idProducto = idProducto;
     }

     public Integer getIdEstablecimiento() {
          return idEstablecimiento;
     }

     public void setIdEstablecimiento(Integer idEstablecimiento) {
          this.idEstablecimiento = idEstablecimiento;
     }

     public Double getPrecio() {
          return precio;
     }

     public void setPrecio(Double precio) {
          this.precio = precio;
     }

     public Establecimiento getEstablecimiento() {
          return establecimiento;
     }

     public void setEstablecimiento(Establecimiento establecimiento) {
          this.establecimiento = establecimiento;
     }

     public Detalle getDetalle() {
          return detalle;
     }

     public void setDetalle(Detalle detalle) {
          this.detalle = detalle;
     }
}
