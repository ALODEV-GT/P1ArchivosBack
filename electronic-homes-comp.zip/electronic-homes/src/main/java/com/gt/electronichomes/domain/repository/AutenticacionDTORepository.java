package com.gt.electronichomes.domain.repository;

import com.gt.electronichomes.domain.dto.EmpleadoDTO;
import com.gt.electronichomes.domain.dto.PermisoDTO;

public interface AutenticacionDTORepository {
    PermisoDTO autenticar(EmpleadoDTO empleadoDTO);
}
