package com.gt.electronichomes.domain.repository;

import com.gt.electronichomes.domain.dto.EmpleadoDTO;
import com.gt.electronichomes.domain.dto.PermisoDTO;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface EmpleadoDTORepository {
    public EmpleadoDTO agregar(EmpleadoDTO empleadoDTO);

    public List<EmpleadoDTO> lista();

    public Boolean eliminar(EmpleadoDTO empleadoDTO);

    public EmpleadoDTO editar(EmpleadoDTO empleadoDTO);

    public PermisoDTO validar(EmpleadoDTO empleadoDTO);
}
