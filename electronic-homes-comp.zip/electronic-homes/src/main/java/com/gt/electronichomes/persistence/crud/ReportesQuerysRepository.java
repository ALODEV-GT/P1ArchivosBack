package com.gt.electronichomes.persistence.crud;

import com.gt.electronichomes.persistence.entity.Detalle;
import com.gt.electronichomes.persistence.entity.DetallePK;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ReportesQuerysRepository extends CrudRepository<Detalle, DetallePK> {
    //REPORTE 1
    @Query(value = "SELECT COUNT(producto.nombre) AS ventas, producto.nombre FROM producto JOIN detalle ON producto.id_producto=detalle.id_producto GROUP BY producto.nombre ORDER BY ventas DESC LIMIT 10;", nativeQuery = true)
    public List<Object[]> masVendidoR1();

    //REPORTE 2
    @Query(value = "SELECT SUM(venta.total) AS total, cliente.nombre, cliente.nit FROM venta JOIN cliente ON venta.nit_cliente = cliente.nit GROUP BY cliente.nit ORDER BY total DESC LIMIT 10;", nativeQuery = true)
    public List<Object[]> clientesTopR2();

    //REPORTE 3
    @Query(value = "SELECT COUNT(establecimiento.nombre) AS ventas,establecimiento.nombre FROM venta JOIN empleado ON venta.id_empleado=empleado.id_empleado JOIN establecimiento ON empleado.id_establecimiento=establecimiento.id_establecimiento GROUP BY(establecimiento.nombre) ORDER BY ventas DESC LIMIT 10;", nativeQuery = true)
    public List<Object[]> sucursalesTopVentasR3();

    //REPORTE 4
    @Query(value = "SELECT SUM(venta.total) AS total, establecimiento.nombre FROM venta JOIN empleado ON venta.id_empleado=empleado.id_empleado JOIN establecimiento ON empleado.id_establecimiento=establecimiento.id_establecimiento GROUP BY establecimiento.nombre ORDER BY total LIMIT 10;", nativeQuery = true)
    public List<Object[]> sucursalesTopIngresosR4();

    //REPORTE 5
    @Query(value = "SELECT empleado.id_empleado, empleado.nombre, COUNT(empleado.id_empleado) AS ventas FROM empleado JOIN venta ON empleado.id_empleado=venta.id_empleado GROUP BY empleado.id_empleado ORDER BY ventas DESC LIMIT 10;", nativeQuery = true)
    public List<Object[]> empleadosTopVentasR5();

    //REPORTE 6
    @Query(value = "SELECT empleado.id_empleado, empleado.nombre, SUM(venta.total) AS total FROM empleado JOIN venta ON empleado.id_empleado=venta.id_empleado GROUP BY empleado.id_empleado ORDER BY total DESC LIMIT 10;", nativeQuery = true)
    public List<Object[]> empleadosTopIngresosR6();

    //REPORTE 7
    @Query(value = "SELECT COUNT(producto.nombre) AS ventas, producto.nombre FROM detalle JOIN producto ON detalle.id_producto=producto.id_producto GROUP BY producto.nombre ORDER BY ventas DESC LIMIT 10;", nativeQuery = true)
    public List<Object[]> productosTopVentasR7();

    //REPORTE 8
    @Query(value = "SELECT SUM(producto.precio) AS total, producto.nombre FROM detalle JOIN producto ON detalle.id_producto=producto.id_producto JOIN venta ON detalle.id_venta=venta.id_venta GROUP BY producto.nombre ORDER BY total DESC LIMIT 10;", nativeQuery = true)
    public List<Object[]> productosTopIngresosR8();

    //REPORTE 9
    @Query(value = "SELECT COUNT(producto.nombre) AS ventas, producto.nombre FROM detalle JOIN producto ON detalle.id_producto=producto.id_producto JOIN venta ON detalle.id_venta=venta.id_venta JOIN empleado ON venta.id_empleado=empleado.id_empleado JOIN establecimiento ON empleado.id_establecimiento=establecimiento.id_establecimiento WHERE establecimiento.id_establecimiento=? GROUP BY producto.nombre ORDER BY ventas DESC LIMIT 5;", nativeQuery = true)
    public List<Object[]> productosTopVentasSucursalR9(Integer idEstablecimiento);

    //REPORTE 10
    @Query(value = "SELECT SUM(producto.precio) AS total, producto.nombre FROM detalle JOIN producto ON detalle.id_producto=producto.id_producto JOIN venta ON detalle.id_venta=venta.id_venta JOIN empleado ON venta.id_empleado=empleado.id_empleado JOIN establecimiento ON empleado.id_establecimiento=establecimiento.id_establecimiento WHERE establecimiento.id_establecimiento=? GROUP BY producto.nombre ORDER BY total DESC LIMIT 5;", nativeQuery = true)
    public List<Object[]> productosTopIngresosSucursalR10(Integer idEstablecimiento);

}
