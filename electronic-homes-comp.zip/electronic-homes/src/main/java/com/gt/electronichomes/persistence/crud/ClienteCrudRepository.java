package com.gt.electronichomes.persistence.crud;

import com.gt.electronichomes.persistence.entity.Cliente;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface ClienteCrudRepository extends CrudRepository<Cliente,String> {
    Cliente findByNit(String nit);

//    @Query(value = "UPDATE cliente SET nit=?, nombre=? WHERE nit=?", nativeQuery = true)
//    void editarCliente(String nitN, String nombre, String nit);

}
