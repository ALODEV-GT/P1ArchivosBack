package com.gt.electronichomes.domain.repository;

import com.gt.electronichomes.domain.dto.RolEmpleadoDTO;

import java.util.List;

public interface RolEmpleadoDTORepository {

    public List<RolEmpleadoDTO> lista();
}
