package com.gt.electronichomes.persistence.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "rol_empleado")
public class RolEmpleado {
    @Id
    @Column(name = "id_rol_empleado")
    private Integer idRolEmpleado;

    private String nombre;

    @OneToMany(mappedBy = "rolEmpleado")
    private List<Empleado> empleados;

    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(List<Empleado> empleados) {
        this.empleados = empleados;
    }

    public Integer getIdRolEmpleado() {
        return idRolEmpleado;
    }

    public void setIdRolEmpleado(Integer idRolEmpleado) {
        this.idRolEmpleado = idRolEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}