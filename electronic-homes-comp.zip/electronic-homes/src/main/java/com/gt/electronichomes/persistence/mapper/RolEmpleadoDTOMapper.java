package com.gt.electronichomes.persistence.mapper;

import com.gt.electronichomes.domain.dto.RolEmpleadoDTO;
import com.gt.electronichomes.persistence.entity.RolEmpleado;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface RolEmpleadoDTOMapper {

    RolEmpleadoDTO toRolEmpleadoDTO(RolEmpleado rolEmpleado);
    List<RolEmpleadoDTO> toRolEmpleadosDTO(List<RolEmpleado> rolEmpleados);

    @InheritInverseConfiguration
    @Mapping(target="empleados", ignore = true)
    RolEmpleado toRolEmpleado(RolEmpleadoDTO rolEmpleadoDTO);

}
