package com.gt.electronichomes.domain.reportesBean;

import java.math.BigDecimal;

public class OctavoReporte {
    private BigDecimal total;
    private String nombreProducto;

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }
}
