package com.gt.electronichomes.domain.dto;

import java.util.List;

public class VentaGDTO {
    private VentaDTO venta;
    private List<ProductoDTO> productos;

    public VentaDTO getVenta() {
        return venta;
    }

    public void setVenta(VentaDTO venta) {
        this.venta = venta;
    }

    public List<ProductoDTO> getProductos() {
        return productos;
    }

    public void setProductos(List<ProductoDTO> productos) {
        this.productos = productos;
    }
}
