package com.gt.electronichomes.persistence.mapper;

import com.gt.electronichomes.domain.dto.TipoProductoDTO;
import com.gt.electronichomes.persistence.entity.TipoProducto;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface TipoProductoDTOMapper {

//    TipoProductoDTO toTipoProductoDTO(TipoProducto tipoProducto);
//
//    @InheritInverseConfiguration
//    @Mapping(target = "productos", ignore = true)
//    TipoProducto toTipoProducto(TipoProductoDTO tipoProducto);

}
