package com.gt.electronichomes.domain.dto;

public class EmpleadoDTO {
    private Integer idEmpleado;
    private Integer idRolEmpleado;
    private Integer idEstablecimiento;
    private String usuario;
    private String contrasena;
    private String nombre;
    private RolEmpleadoDTO rolEmpleado;
    private EstablecimientoDTO establecimiento;

    public Integer getIdEstablecimiento() {
        return idEstablecimiento;
    }

    public void setIdEstablecimiento(Integer idEstablecimiento) {
        this.idEstablecimiento = idEstablecimiento;
    }

    public RolEmpleadoDTO getRolEmpleado() {
        return rolEmpleado;
    }

    public void setRolEmpleado(RolEmpleadoDTO rolEmpleado) {
        this.rolEmpleado = rolEmpleado;
    }

    public EstablecimientoDTO getEstablecimiento() {
        return establecimiento;
    }

    public void setEstablecimiento(EstablecimientoDTO establecimiento) {
        this.establecimiento = establecimiento;
    }

    public Integer getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(Integer idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public Integer getIdRolEmpleado() {
        return idRolEmpleado;
    }

    public void setIdRolEmpleado(Integer idRolEmpleado) {
        this.idRolEmpleado = idRolEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
}
