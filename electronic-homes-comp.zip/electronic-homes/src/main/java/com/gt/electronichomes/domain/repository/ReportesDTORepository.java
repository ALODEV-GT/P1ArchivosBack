package com.gt.electronichomes.domain.repository;

import com.gt.electronichomes.domain.reportesBean.*;

import java.util.List;

public interface ReportesDTORepository {
    public List<PrimerReporte> masVendidoR1();

    public List<SegundoReporte> clientesTopR2();

    public List<TercerReporte> sucursalesTopVentasR3();

    public List<CuartoReporte> sucursalesTopIngresosR4();

    public List<QuintoReporte> empleadosTopVentasR5();

    public List<SextoReporte> empleadosTopIngresosR6();

    public List<SeptimoReporte> productosTopVentasR7();

    public List<OctavoReporte> productosTopIngresosR8();

    public List<NovenoReporte> productosTopVentasSucursalR9(Integer idEstablecimiento);

    public List<DecimoReporte> productosTopIngresosSucursalR10(Integer idEstablecimiento);

}
