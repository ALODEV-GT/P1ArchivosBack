package com.gt.electronichomes.domain.service;

import com.gt.electronichomes.domain.repository.TipoEstablecimientoDTORepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TipoEstablecimientoService {
    @Autowired
    private TipoEstablecimientoDTORepository tedtor;

}
