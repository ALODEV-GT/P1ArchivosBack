package com.gt.electronichomes.persistence.crud;

import com.gt.electronichomes.persistence.entity.Empleado;
import org.springframework.data.repository.CrudRepository;

public interface EmpleadoCrudRepository extends CrudRepository<Empleado, Integer> {
    Empleado findByUsuario(String usuario);

}
