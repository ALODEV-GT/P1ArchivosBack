package com.gt.electronichomes.domain.reportesBean;

import java.math.BigInteger;

public class QuintoReporte {
    private Integer idEmpleado;
    private String nombreEmpleado;
    private BigInteger noVentas;

    public Integer getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(Integer idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public BigInteger getNoVentas() {
        return noVentas;
    }

    public void setNoVentas(BigInteger noVentas) {
        this.noVentas = noVentas;
    }
}
