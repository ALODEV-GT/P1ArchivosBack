package com.gt.electronichomes.domain.dto;

public class RolEmpleadoDTO {
    private Integer idRolEmpleado;
    private String nombre;

    public RolEmpleadoDTO() {

    }

    public RolEmpleadoDTO(Integer idRolEmpleado, String nombre) {
        this.idRolEmpleado = idRolEmpleado;
        this.nombre = nombre;
    }

    public Integer getIdRolEmpleado() {
        return idRolEmpleado;
    }

    public void setIdRolEmpleado(Integer idRolEmpleado) {
        this.idRolEmpleado = idRolEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
