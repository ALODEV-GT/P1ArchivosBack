package com.gt.electronichomes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectronicHomesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectronicHomesApplication.class, args);
	}

}
