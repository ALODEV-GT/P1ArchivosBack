package com.gt.electronichomes.web.controller;

import com.gt.electronichomes.domain.service.TipoProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//@CrossOrigin(origins="http://localhost:4200",maxAge=3600)
//@RestController
//@RequestMapping("/tipo-producto")
public class TipoProductoController {
    //@Autowired
    //private TipoProductoService tpd;
}
