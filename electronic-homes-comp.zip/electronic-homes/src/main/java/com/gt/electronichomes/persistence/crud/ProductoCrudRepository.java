package com.gt.electronichomes.persistence.crud;

import com.gt.electronichomes.persistence.entity.Producto;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ProductoCrudRepository extends CrudRepository<Producto, Integer> {

    List<Producto> findProductoByIdEstablecimientoAndDisponible(Integer idEstablecimieto, Boolean disponible);

}
