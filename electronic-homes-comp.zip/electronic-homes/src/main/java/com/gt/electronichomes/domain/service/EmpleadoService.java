package com.gt.electronichomes.domain.service;

import com.gt.electronichomes.domain.dto.ClienteDTO;
import com.gt.electronichomes.domain.dto.EmpleadoDTO;
import com.gt.electronichomes.domain.dto.PermisoDTO;
import com.gt.electronichomes.domain.repository.EmpleadoDTORepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Service
public class EmpleadoService  {
     @Autowired
     private EmpleadoDTORepository edtor;

    public EmpleadoDTO agregar(EmpleadoDTO empleadoDTO) {
        return edtor.agregar(empleadoDTO);
    }

    public List<EmpleadoDTO> lista() {
        return edtor.lista();
    }

    public Boolean eliminar(EmpleadoDTO empleadoDTO) {
        return edtor.eliminar(empleadoDTO);
    }

    public EmpleadoDTO editar(EmpleadoDTO empleadoDTO){
        return edtor.editar(empleadoDTO);
    }

    public PermisoDTO validar(EmpleadoDTO empleadoDTO){
        return edtor.validar(empleadoDTO);
    }
}
