package com.gt.electronichomes.persistence.repository;

import com.gt.electronichomes.domain.dto.ClienteDTO;
import com.gt.electronichomes.domain.repository.ClienteDTORepository;
import com.gt.electronichomes.persistence.crud.ClienteCrudRepository;
import com.gt.electronichomes.persistence.crud.VentaCrudRepository;
import com.gt.electronichomes.persistence.entity.Cliente;
import com.gt.electronichomes.persistence.entity.Venta;
import com.gt.electronichomes.persistence.mapper.ClienteDTOMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ClienteRepository implements ClienteDTORepository {
    @Autowired
    private ClienteCrudRepository ccr;

    @Autowired
    private ClienteDTOMapper cdtom;

    @Autowired
    private VentaCrudRepository vcr;


    @Override
    public ClienteDTO validar(ClienteDTO clienteDTO) {
        Cliente clienteFind = ccr.findByNit(clienteDTO.getNit());
        if(clienteFind == null){
            clienteDTO.setExiste(false);
            return clienteDTO;
        }else{
            clienteDTO.setExiste(true);
            clienteDTO.setNombre(clienteFind.getNombre());
            return clienteDTO;
        }
    }

    @Override
    public ClienteDTO agregar(ClienteDTO clienteDTO) {
        ccr.save(cdtom.toCliente(clienteDTO));
        clienteDTO.setExiste(true);
        return clienteDTO;
    }

    @Override
    public List<ClienteDTO> lista() {
        List<Cliente> clientes = (List<Cliente>) ccr.findAll();
        return cdtom.toClientesDTO(clientes);
    }

    @Override
    public Boolean eliminar(String nit) {
        Cliente clienteCF = ccr.findByNit("0");

        List<Venta> ventas = vcr.findAllByNitCliente(nit);
        for (Venta venta: ventas) {
            venta.setNitCliente(clienteCF.getNit());
            venta.setCliente(clienteCF);
        }

        vcr.saveAll(ventas);

        ccr.delete(new Cliente(nit,""));
        if(ccr.findByNit(nit) == null){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public ClienteDTO editar(ClienteDTO clienteDTO) {
        //Solo se acutalizara el nombre
        Cliente clt = ccr.findByNit(clienteDTO.getNit());
        clt.setNombre(clienteDTO.getNombre());
        ccr.save(clt);
        return clienteDTO;
    }
}
