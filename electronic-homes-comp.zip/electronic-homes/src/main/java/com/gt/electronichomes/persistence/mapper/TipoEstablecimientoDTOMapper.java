package com.gt.electronichomes.persistence.mapper;

import com.gt.electronichomes.domain.dto.TipoEstablecimientoDTO;
import com.gt.electronichomes.persistence.entity.TipoEstablecimiento;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface TipoEstablecimientoDTOMapper {

    TipoEstablecimientoDTO toTipoEstablecimientoDTO(TipoEstablecimiento tipoEstablecimiento);

    @InheritInverseConfiguration
    @Mapping(target="establecimientos", ignore = true)
    TipoEstablecimiento toTipoEstablecimiento(TipoEstablecimientoDTO tipoEstablecimientoDTO);
}
