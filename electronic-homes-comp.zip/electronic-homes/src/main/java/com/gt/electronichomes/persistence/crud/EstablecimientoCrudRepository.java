package com.gt.electronichomes.persistence.crud;

import com.gt.electronichomes.persistence.entity.Establecimiento;
import org.springframework.data.repository.CrudRepository;

public interface EstablecimientoCrudRepository extends CrudRepository<Establecimiento,Integer> {
}
