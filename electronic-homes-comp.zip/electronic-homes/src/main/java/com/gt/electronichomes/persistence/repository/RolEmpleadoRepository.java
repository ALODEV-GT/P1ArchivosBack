package com.gt.electronichomes.persistence.repository;

import com.gt.electronichomes.domain.dto.RolEmpleadoDTO;
import com.gt.electronichomes.domain.repository.RolEmpleadoDTORepository;
import com.gt.electronichomes.persistence.crud.RolEmpleadoCrudRepository;
import com.gt.electronichomes.persistence.entity.RolEmpleado;
import com.gt.electronichomes.persistence.mapper.RolEmpleadoDTOMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RolEmpleadoRepository implements RolEmpleadoDTORepository {

    @Autowired
    private RolEmpleadoCrudRepository recr;

    @Autowired
    private RolEmpleadoDTOMapper redtom;

    @Override
    public List<RolEmpleadoDTO> lista() {
        List<RolEmpleado> rolEmpleados = (List<RolEmpleado>) recr.findAll();
        return redtom.toRolEmpleadosDTO(rolEmpleados);
    }
}
