package com.gt.electronichomes.persistence.repository;

import com.gt.electronichomes.domain.repository.TipoEstablecimientoDTORepository;
import org.springframework.stereotype.Repository;

@Repository
public class TipoEstablecimientoRepository implements TipoEstablecimientoDTORepository {
}
