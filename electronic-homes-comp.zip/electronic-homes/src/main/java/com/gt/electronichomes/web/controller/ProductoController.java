package com.gt.electronichomes.web.controller;

import com.gt.electronichomes.domain.dto.ClienteDTO;
import com.gt.electronichomes.domain.dto.ProductoDTO;
import com.gt.electronichomes.domain.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200",maxAge=3600)
@RestController
@RequestMapping("/producto")
public class ProductoController {
    @Autowired
    private ProductoService ps;

    @GetMapping("/lista/{idEstablecimiento}")
    public List<ProductoDTO> lista(@PathVariable Integer idEstablecimiento) {
        return ps.listar(idEstablecimiento);
    }

    @PostMapping("/transferir")
    public ProductoDTO transferir(@RequestBody ProductoDTO productoDTO) {
        return ps.transferir(productoDTO);
    }

    @PostMapping("/agregar")
    public ProductoDTO agregar(@RequestBody ProductoDTO productoDTO) {
        return ps.agregar(productoDTO);
    }

    @PostMapping("/editar")
    public ProductoDTO editar(@RequestBody ProductoDTO productoDTO) {
        return ps.editar(productoDTO);
    }
}
