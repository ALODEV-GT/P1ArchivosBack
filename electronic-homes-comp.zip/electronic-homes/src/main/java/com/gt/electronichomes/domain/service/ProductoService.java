package com.gt.electronichomes.domain.service;

import com.gt.electronichomes.domain.dto.ProductoDTO;
import com.gt.electronichomes.domain.repository.ProductoDTORepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoService {
    @Autowired
    private ProductoDTORepository pdtor;

    public List<ProductoDTO> listar(Integer idEstablecimiento){
        return pdtor.listar(idEstablecimiento);
    }

    public ProductoDTO transferir(ProductoDTO productoDTO){
        return pdtor.transferir(productoDTO);
    }

    public ProductoDTO agregar(ProductoDTO productoDTO){
        return pdtor.agregar(productoDTO);
    }

    public ProductoDTO editar(ProductoDTO productoDTO){
        return pdtor.editar(productoDTO);
    }
}
