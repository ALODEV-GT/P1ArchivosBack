package com.gt.electronichomes.domain.service;

import com.gt.electronichomes.domain.repository.TipoProductoDTORepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TipoProductoService {
    @Autowired
    private TipoProductoDTORepository tpdtor;
}
