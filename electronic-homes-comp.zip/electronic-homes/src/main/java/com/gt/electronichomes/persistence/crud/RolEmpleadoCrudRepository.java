package com.gt.electronichomes.persistence.crud;

import com.gt.electronichomes.persistence.entity.RolEmpleado;
import org.springframework.data.repository.CrudRepository;

public interface RolEmpleadoCrudRepository extends CrudRepository<RolEmpleado, Integer> {
}
