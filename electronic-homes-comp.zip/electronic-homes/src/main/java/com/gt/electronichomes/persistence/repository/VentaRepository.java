package com.gt.electronichomes.persistence.repository;

import com.gt.electronichomes.domain.dto.VentaDTO;
import com.gt.electronichomes.domain.dto.VentaGDTO;
import com.gt.electronichomes.domain.repository.VentaDTORepository;
import com.gt.electronichomes.persistence.crud.DetalleCrudRepository;
import com.gt.electronichomes.persistence.crud.ProductoCrudRepository;
import com.gt.electronichomes.persistence.crud.VentaCrudRepository;
import com.gt.electronichomes.persistence.entity.Detalle;
import com.gt.electronichomes.persistence.entity.DetallePK;
import com.gt.electronichomes.persistence.entity.Producto;
import com.gt.electronichomes.persistence.entity.Venta;
import com.gt.electronichomes.persistence.mapper.ProductoDTOMapper;
import com.gt.electronichomes.persistence.mapper.VentaDTOMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class VentaRepository implements VentaDTORepository {

    @Autowired
    private VentaCrudRepository vcr;

    @Autowired
    private ProductoCrudRepository pcr;

    @Autowired
    private DetalleCrudRepository dcr;

    @Autowired
    private VentaDTOMapper vdtom;

    @Autowired
    private ProductoDTOMapper pdtom;

    @Override
    public VentaDTO comprar(VentaGDTO ventaG) {
        Venta venta = vdtom.toVenta(ventaG.getVenta());
        List<Producto> productos = pdtom.toProductos(ventaG.getProductos());
        Venta ventaGuardada = vcr.save(venta);
        int idVenta = ventaGuardada.getIdVenta();
        //Guardar detalles
        List<Detalle> detalles = new ArrayList<>();

        for (Producto producto: productos) {
            detalles.add(new Detalle(new DetallePK(idVenta, producto.getIdProducto())));
        }
        dcr.saveAll(detalles);

        //Cambiar el estado de los productos
        for (Producto producto: productos) {
            producto.setDisponible(false);
        }
        pcr.saveAll(productos);

        return vdtom.toVentaDTO(ventaGuardada);
    }
}
