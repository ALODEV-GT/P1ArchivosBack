package com.gt.electronichomes.persistence.mapper;

import com.gt.electronichomes.domain.dto.ProductoDTO;
import com.gt.electronichomes.persistence.entity.Producto;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring",uses = {EstablecimientoDTOMapper.class})
public interface ProductoDTOMapper {

    ProductoDTO toProductoDTO(Producto producto);
    List<ProductoDTO> toProductosDTO(List<Producto> productos);

    @InheritInverseConfiguration
    @Mapping(target = "detalle", ignore = true)
    Producto toProducto(ProductoDTO producto);
    List<Producto> toProductos(List<ProductoDTO> productos);

}
