package com.gt.electronichomes.domain.dto;

public class TipoEstablecimientoDTO {
    private Integer idTipoEstablecimiento;
    private String descripcion;

    public Integer getIdTipoEstablecimiento() {
        return idTipoEstablecimiento;
    }

    public void setIdTipoEstablecimiento(Integer idTipoEstablecimiento) {
        this.idTipoEstablecimiento = idTipoEstablecimiento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
