package com.gt.electronichomes.web.controller;

import com.gt.electronichomes.domain.dto.ClienteDTO;
import com.gt.electronichomes.domain.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200",maxAge=3600)
@RestController
@RequestMapping("/cliente")
public class ClienteController {
    @Autowired
    private ClienteService cs;

    @PostMapping("/validar")
    public ClienteDTO validar(@RequestBody ClienteDTO cliente) {
        return cs.validar(cliente);
    }

    @PostMapping("/agregar")
    public ClienteDTO agregar(@RequestBody ClienteDTO cliente) {
        return cs.agregar(cliente);
    }

    @GetMapping("/lista")
    public List<ClienteDTO> lista() {
        return cs.lista();
    }

    @PostMapping("/eliminar")
    public Boolean eliminar(@RequestBody String nit) {
         return cs.eliminar(nit);
    }

    @PostMapping("/editar")
    public ClienteDTO editar(@RequestBody ClienteDTO cliente){
        return cs.editar(cliente);
    }

    // /editar/nit-dinamico
//    @PostMapping("/editar/{nit}")
//    public ClienteDTO editar(@RequestBody ClienteDTO cliente, @PathVariable String nit){
//        return cs.editar(cliente, nit);
//    }

}
