package com.gt.electronichomes.domain.service;

import org.springframework.stereotype.Service;

@Service
public class DetalleService {

}
