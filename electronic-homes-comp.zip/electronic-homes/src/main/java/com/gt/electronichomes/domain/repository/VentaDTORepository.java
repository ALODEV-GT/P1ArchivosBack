package com.gt.electronichomes.domain.repository;

import com.gt.electronichomes.domain.dto.VentaDTO;
import com.gt.electronichomes.domain.dto.VentaGDTO;

public interface VentaDTORepository {
    VentaDTO comprar(VentaGDTO venta);
}
