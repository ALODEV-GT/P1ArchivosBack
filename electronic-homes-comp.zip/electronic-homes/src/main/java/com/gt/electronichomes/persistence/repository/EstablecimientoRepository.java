package com.gt.electronichomes.persistence.repository;

import com.gt.electronichomes.domain.dto.EstablecimientoDTO;
import com.gt.electronichomes.domain.repository.EstablecimientoDTORepository;
import com.gt.electronichomes.persistence.crud.EstablecimientoCrudRepository;
import com.gt.electronichomes.persistence.entity.Establecimiento;
import com.gt.electronichomes.persistence.mapper.EstablecimientoDTOMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EstablecimientoRepository implements EstablecimientoDTORepository {

    @Autowired
    private EstablecimientoCrudRepository ecr;

    @Autowired
    private EstablecimientoDTOMapper edtom;

    public List<EstablecimientoDTO> listar(){
        List<Establecimiento> establecimientos = (List<Establecimiento>) ecr.findAll();
        return edtom.toEstablecimientosDTO(establecimientos);
    }
}
