package com.gt.electronichomes.domain.service;

import com.gt.electronichomes.domain.dto.EstablecimientoDTO;
import com.gt.electronichomes.domain.repository.EstablecimientoDTORepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EstablecimientoService {
    @Autowired
    private EstablecimientoDTORepository edtor;

    public List<EstablecimientoDTO> listar(){
        return edtor.listar();
    }
}
