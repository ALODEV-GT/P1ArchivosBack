package com.gt.electronichomes.domain.service;

import com.gt.electronichomes.domain.dto.EmpleadoDTO;
import com.gt.electronichomes.domain.dto.PermisoDTO;
import com.gt.electronichomes.domain.repository.AutenticacionDTORepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AutenticacionService {
    @Autowired
    private AutenticacionDTORepository adtor;

    public PermisoDTO autenticar(EmpleadoDTO empleadoDTO){
        return adtor.autenticar(empleadoDTO);
    }
}
