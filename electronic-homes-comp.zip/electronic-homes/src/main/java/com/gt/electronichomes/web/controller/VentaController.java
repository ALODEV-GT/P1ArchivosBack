package com.gt.electronichomes.web.controller;

import com.gt.electronichomes.domain.dto.VentaDTO;
import com.gt.electronichomes.domain.dto.VentaGDTO;
import com.gt.electronichomes.domain.service.VentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins="http://localhost:4200",maxAge=3600)
@RestController
@RequestMapping("/venta")
public class VentaController {
    @Autowired
    private VentaService vs;

    @PostMapping("/comprar")
    public VentaDTO comprar(@RequestBody VentaGDTO venta) {
        return vs.comprar(venta);
    }
}
