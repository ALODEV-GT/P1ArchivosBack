package com.gt.electronichomes.domain.repository;

import com.gt.electronichomes.domain.dto.EstablecimientoDTO;

import java.util.List;

public interface EstablecimientoDTORepository {

    public List<EstablecimientoDTO> listar();
}
