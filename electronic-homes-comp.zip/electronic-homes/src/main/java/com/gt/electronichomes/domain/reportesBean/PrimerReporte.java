package com.gt.electronichomes.domain.reportesBean;

import java.math.BigInteger;

public class PrimerReporte {
    private BigInteger ventas;
    private String nombre;

    public BigInteger getVentas() {
        return ventas;
    }

    public void setVentas(BigInteger ventas) {
        this.ventas = ventas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
