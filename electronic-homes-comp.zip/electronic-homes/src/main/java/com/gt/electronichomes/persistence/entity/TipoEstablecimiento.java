package com.gt.electronichomes.persistence.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "tipo_establecimiento")
public class TipoEstablecimiento {
    @Id
    @Column(name = "id_tipo_establecimiento")
    private Integer idTipoEstablecimiento;

    private String descripcion;

    @OneToMany(mappedBy = "tipoEstablecimiento")
    private List<Establecimiento> establecimientos;

    public List<Establecimiento> getEstablecimientos() {
        return establecimientos;
    }

    public void setEstablecimientos(List<Establecimiento> establecimientos) {
        this.establecimientos = establecimientos;
    }

    public Integer getIdTipoEstablecimiento() {
        return idTipoEstablecimiento;
    }

    public void setIdTipoEstablecimiento(Integer idTipoEstablecimiento) {
        this.idTipoEstablecimiento = idTipoEstablecimiento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
