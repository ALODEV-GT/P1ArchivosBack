package com.gt.electronichomes.persistence.crud;

import com.gt.electronichomes.persistence.entity.Detalle;
import com.gt.electronichomes.persistence.entity.DetallePK;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface DetalleCrudRepository extends CrudRepository<Detalle, DetallePK> {


}
