package com.gt.electronichomes.domain.dto;

public class DetalleDTO {
    private VentaDTO venta;
    private ProductoDTO producto;

    public VentaDTO getVenta() {
        return venta;
    }

    public void setVenta(VentaDTO venta) {
        this.venta = venta;
    }

    public ProductoDTO getProducto() {
        return producto;
    }

    public void setProducto(ProductoDTO producto) {
        this.producto = producto;
    }
}
