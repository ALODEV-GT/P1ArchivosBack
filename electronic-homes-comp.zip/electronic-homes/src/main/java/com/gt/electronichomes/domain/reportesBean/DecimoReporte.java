package com.gt.electronichomes.domain.reportesBean;

import java.math.BigDecimal;

public class DecimoReporte {
    private BigDecimal noVentas;
    private String nombreProducto;

    public BigDecimal getNoVentas() {
        return noVentas;
    }

    public void setNoVentas(BigDecimal noVentas) {
        this.noVentas = noVentas;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }
}
