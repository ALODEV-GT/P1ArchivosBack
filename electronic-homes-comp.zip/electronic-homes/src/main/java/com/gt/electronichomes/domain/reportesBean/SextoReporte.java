package com.gt.electronichomes.domain.reportesBean;

import java.math.BigDecimal;
import java.math.BigInteger;

public class SextoReporte {
    private Integer idEmpleado;
    private String nombreEmpleado;
    private BigDecimal total;

    public Integer getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(Integer idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }
}
