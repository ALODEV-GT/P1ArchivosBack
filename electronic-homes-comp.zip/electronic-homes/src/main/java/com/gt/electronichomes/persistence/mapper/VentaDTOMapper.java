package com.gt.electronichomes.persistence.mapper;

import com.gt.electronichomes.domain.dto.VentaDTO;
import com.gt.electronichomes.persistence.entity.Venta;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring", uses = { ClienteDTOMapper.class, EmpleadoDTOMapper.class})
public interface VentaDTOMapper {

    VentaDTO toVentaDTO(Venta venta);

    @InheritInverseConfiguration
    @Mapping(target="detalles", ignore = true)
    Venta toVenta(VentaDTO venta);
}
