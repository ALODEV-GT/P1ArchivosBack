package com.gt.electronichomes.domain.repository;

import com.gt.electronichomes.domain.dto.ClienteDTO;

import java.util.List;

public interface ClienteDTORepository {

    ClienteDTO validar(ClienteDTO cliente);

    ClienteDTO agregar(ClienteDTO cliente);

    List<ClienteDTO> lista();

    Boolean eliminar(String nit);

    ClienteDTO editar(ClienteDTO clienteDTO);

}
