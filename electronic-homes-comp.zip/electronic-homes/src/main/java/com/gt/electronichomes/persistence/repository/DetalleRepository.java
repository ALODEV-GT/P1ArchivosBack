package com.gt.electronichomes.persistence.repository;

import com.gt.electronichomes.domain.reportesBean.PrimerReporte;
import com.gt.electronichomes.domain.repository.DetalleDTORepository;
import com.gt.electronichomes.persistence.crud.DetalleCrudRepository;
import com.gt.electronichomes.persistence.crud.ReportesQuerysRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

@Repository
public class DetalleRepository implements DetalleDTORepository {

    @Autowired
    private DetalleCrudRepository dcr;




}
