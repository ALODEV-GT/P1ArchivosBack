package com.gt.electronichomes.domain.repository;

public interface TipoEstablecimientoDTORepository {
}
