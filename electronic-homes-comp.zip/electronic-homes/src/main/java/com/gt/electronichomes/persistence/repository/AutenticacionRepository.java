package com.gt.electronichomes.persistence.repository;

import com.gt.electronichomes.domain.dto.EmpleadoDTO;
import com.gt.electronichomes.domain.dto.EstablecimientoDTO;
import com.gt.electronichomes.domain.dto.PermisoDTO;
import com.gt.electronichomes.domain.dto.RolEmpleadoDTO;
import com.gt.electronichomes.domain.repository.AutenticacionDTORepository;
import com.gt.electronichomes.persistence.crud.AutenticacionCrudRepository;
import com.gt.electronichomes.persistence.entity.Empleado;
import com.gt.electronichomes.persistence.mapper.EmpleadoDTOMapper;
import com.gt.electronichomes.persistence.mapper.EstablecimientoDTOMapper;
import com.gt.electronichomes.persistence.mapper.RolEmpleadoDTOMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AutenticacionRepository implements AutenticacionDTORepository {

    @Autowired
    private AutenticacionCrudRepository acr;

    @Autowired
    private EmpleadoDTOMapper edtom;

    @Autowired
    private RolEmpleadoDTOMapper redtom;

    @Autowired
    private EstablecimientoDTOMapper estdtom;

    @Override
    public PermisoDTO autenticar(EmpleadoDTO empleadoDTO) {
        Empleado empleado = edtom.toEmpleado(empleadoDTO);
        Empleado emp = acr.findByUsuarioAndContrasena(empleado.getUsuario(), empleado.getContrasena());
        if (emp == null){
            RolEmpleadoDTO rol = new RolEmpleadoDTO(0,"inexistente");
            EstablecimientoDTO establecimiento = new EstablecimientoDTO();
            return new PermisoDTO(rol, establecimiento, 0,"");
        }else{
            RolEmpleadoDTO rol =  redtom.toRolEmpleadoDTO(emp.getRolEmpleado());
            EstablecimientoDTO establecimiento = estdtom.toEstablecimientoDTO(emp.getEstablecimiento());
            return new PermisoDTO(rol, establecimiento, emp.getIdEmpleado(), emp.getNombre());
        }
    }
}

