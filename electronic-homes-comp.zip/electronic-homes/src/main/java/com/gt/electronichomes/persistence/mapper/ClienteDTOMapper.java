package com.gt.electronichomes.persistence.mapper;

import com.gt.electronichomes.domain.dto.ClienteDTO;
import com.gt.electronichomes.persistence.entity.Cliente;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ClienteDTOMapper {

    @Mapping(target = "existe", ignore = true)
    ClienteDTO toClienteDTO(Cliente cliente);

    List<ClienteDTO> toClientesDTO(List<Cliente> clientes);

    @InheritInverseConfiguration
    @Mapping(target = "ventas", ignore = true)
    Cliente toCliente(ClienteDTO cliente);

}