package com.gt.electronichomes.persistence.crud;

import com.gt.electronichomes.persistence.entity.TipoProducto;
import org.springframework.data.repository.CrudRepository;

public interface TipoProductoCrudRepository extends CrudRepository<TipoProducto, Integer> {
}
