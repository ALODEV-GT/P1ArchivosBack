package com.gt.electronichomes.web.controller;

import com.gt.electronichomes.domain.dto.EmpleadoDTO;
import com.gt.electronichomes.domain.dto.PermisoDTO;
import com.gt.electronichomes.domain.service.EmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200",maxAge=3600)
@RestController
@RequestMapping("/empleado")
public class EmpleadoController {

    @Autowired
    private EmpleadoService es;

    @PostMapping("/agregar")
    public EmpleadoDTO agregar(@RequestBody EmpleadoDTO empleadoDTO) {
        return es.agregar(empleadoDTO);
    }

    @GetMapping("/lista")
    public List<EmpleadoDTO> lista() {
        return es.lista();
    }

    @PostMapping("/eliminar")
    public Boolean eliminar(@RequestBody EmpleadoDTO empleadoDTO) {
        return es.eliminar(empleadoDTO);
    }

    @PostMapping("/editar")
    public EmpleadoDTO editar(@RequestBody EmpleadoDTO empleadoDTO){
        return es.editar(empleadoDTO);
    }

    @PostMapping("/validar")
    public PermisoDTO validar(@RequestBody EmpleadoDTO empleadoDTO) {
        return es.validar(empleadoDTO);
    }
}
