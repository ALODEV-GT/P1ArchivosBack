package com.gt.electronichomes.persistence.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "tipo_producto")
public class TipoProducto {
    @Id
    @Column(name = "id_tipo_producto")
    private Integer idTipoProducto;
    private String nombre;
    private Integer unidades;

    public Integer getIdTipoProducto() {
        return idTipoProducto;
    }

    public void setIdTipoProducto(Integer idTipoProducto) {
        this.idTipoProducto = idTipoProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getUnidades() {
        return unidades;
    }

    public void setUnidades(Integer unidades) {
        this.unidades = unidades;
    }

}
