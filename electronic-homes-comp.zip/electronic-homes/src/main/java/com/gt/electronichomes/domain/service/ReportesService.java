package com.gt.electronichomes.domain.service;

import com.gt.electronichomes.domain.reportesBean.*;
import com.gt.electronichomes.domain.repository.ReportesDTORepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportesService {
    @Autowired
    private ReportesDTORepository rdtor;

    public List<PrimerReporte> masVendidoR1() {
        return rdtor.masVendidoR1();
    }

    public List<SegundoReporte> clientesTopR2() {
        return rdtor.clientesTopR2();
    }

    public List<TercerReporte> sucursalesTopVentasR3() {
        return rdtor.sucursalesTopVentasR3();
    }

    public List<CuartoReporte> sucursalesTopIngresosR4() {
        return rdtor.sucursalesTopIngresosR4();
    }

    public List<QuintoReporte> empleadosTopVentasR5() {
        return rdtor.empleadosTopVentasR5();
    }

    public List<SextoReporte> empleadosTopIngresosR6() {
        return rdtor.empleadosTopIngresosR6();
    }

    public List<SeptimoReporte> productosTopVentasR7() {
        return rdtor.productosTopVentasR7();
    }

    public List<OctavoReporte> productosTopIngresosR8() {
        return rdtor.productosTopIngresosR8();
    }

    public List<NovenoReporte> productosTopVentasSucursalR9(Integer idEstablecimiento) {
        return rdtor.productosTopVentasSucursalR9(idEstablecimiento);
    }

    public List<DecimoReporte> productosTopIngresosSucursalR10(Integer idEstablecimiento) {
        return rdtor.productosTopIngresosSucursalR10(idEstablecimiento);
    }
}
