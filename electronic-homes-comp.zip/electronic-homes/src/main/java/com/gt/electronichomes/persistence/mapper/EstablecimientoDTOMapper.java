package com.gt.electronichomes.persistence.mapper;

import com.gt.electronichomes.domain.dto.EstablecimientoDTO;
import com.gt.electronichomes.persistence.entity.Establecimiento;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring", uses = {TipoEstablecimientoDTOMapper.class})
public interface EstablecimientoDTOMapper {

    EstablecimientoDTO toEstablecimientoDTO(Establecimiento establecimiento);
    List<EstablecimientoDTO> toEstablecimientosDTO(List<Establecimiento> establecimientos);

    @InheritInverseConfiguration
    @Mapping(target = "empleados", ignore = true)
    @Mapping(target = "productos", ignore = true)
    Establecimiento toEstablecimiento(EstablecimientoDTO establecimientoDTO);
}
