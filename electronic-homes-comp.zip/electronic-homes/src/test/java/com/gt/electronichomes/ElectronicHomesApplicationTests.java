package com.gt.electronichomes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectronicHomesApplicationTests {

	@Test
	void contextLoads() {
	}

}
